package com.noesinformatica.test;

public class Term {
	
	private Long lastUserId;
	private String termData;
	
	public Long getLastUserId() {
		return lastUserId;
	}
	public void setLastUserId(Long lastUserId) {
		this.lastUserId = lastUserId;
	}
	public String getTermData() {
		return termData;
	}
	public void setTermData(String termData) {
		this.termData = termData;
	}
	
	

}
